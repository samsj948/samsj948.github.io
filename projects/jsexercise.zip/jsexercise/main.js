console.log('Julia');

console.log(2);

console.log('2');

console.log(true);

var firstArray = ['j,u,l,i,a'];

console.log(['j,u,l,i,a']);

console.log([7,'example',false]);

console.log('julia'+'sams');

console.log(75+25);

console.log('j','a');

var superEx = ('supercalifragilisticexpialidocious');
console.log(superEx.length);

console.log(5==4);

if (students=16) {
console.log('yes all students are present');
} else {
console.log('no, not all students are here');
}

/*var today = new Date().getHours();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();


/*if (today >= 19 && <= 22) {
console.log("it is time");
} else {
console.log('not the time!');
}*/
var d = new Date();
var todayDay = [d.getDay()];

if (todayDay=0) {
console.log("howdy");
} else if (todayDay=1) {
console.log("wassup");
} else if (todayDay=2) {
console.log("ayyo");
} else if (todayDay=3) {
console.log("whats good");
} else if (todayDay=4) {
console.log("hello");
} else if (todayDay=5) {
console.log("yabbadabba")
} else (todayDay=6) 
console.log("greetings")

/*
function myFunction() {
  var d = new Date();
  var weekday = new Array(7);
  weekday[0] = "Sunday";
  weekday[1] = "Monday";
  weekday[2] = "Tuesday";
  weekday[3] = "Wednesday";
  weekday[4] = "Thursday";
  weekday[5] = "Friday";
  weekday[6] = "Saturday";

  var n = weekday[d.getDay()];
  document.getElementById("demo").innerHTML = n;
}*/

var food = new Array(3);
food[0] = "Peaches";
food[1] = "Potatoes";
food[2] = "Hummus";

var animal = new Array(3);
animal[0] = "snails";
animal[1] = "cows";
animal[2] = "cats";

var place = new Array(3);
place[0] = "mountains";
place[1] = "beach";
place[2] = "car";

var pokemon = new Array(3);
pokemon[0] = "Chansey";
pokemon[1] = "Sunkern";
pokemon[2] = "Swinub";

var allArray = new Array(4);
[food],[animal],[place],[pokemon]
console.log(allArray)

console.log(food, animal, place, pokemon)